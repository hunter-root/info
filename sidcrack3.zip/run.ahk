; Find EXE in current script directory
ExePath := A_ScriptDir . "\action.exe"

; Window Size
WinX := 100
WinY := 100
WinWidth := 1250
WinHeight := 650

; Run EXE
Run, %ExePath%, , , PID

; Wait until window is fully ready
WinWait, ahk_pid %PID%, , 10
if ErrorLevel
{
    MsgBox, craker.exe not found or window did not open within 10 seconds.
    ExitApp
}

; Force move and resize window
Loop 10
{
    WinMove, ahk_pid %PID%, , WinX, WinY, WinWidth, WinHeight
    Sleep, 100
}