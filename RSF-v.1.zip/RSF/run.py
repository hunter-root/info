# -*- coding: utf-8 -*-
from __future__ import print_function
import sys
import os
from colorama import Fore, Style, init

# Initialize colorama
init()

def input_Fox(txt):
    try:
        if sys.version_info[0] < 3:
            return raw_input(txt).strip()
        else:
            sys.stdout.write(txt)
            return input().strip()
    except:
        return False

def find_largest_txt_file():
    txt_files = [f for f in os.listdir('.') if f.endswith('.txt')]
    if not txt_files:
        print(Fore.RED + "No .txt files found in the current directory." + Style.RESET_ALL)
        sys.exit(1)
    largest_file = max(txt_files, key=lambda f: os.path.getsize(f))
    return largest_file

def count_lines(filename):
    count = 0
    with open(filename, 'r') as f:
        for _ in f:
            count += 1
    return count

# Welcome banner
print(Fore.CYAN + """
========================================================
=               [+] Hunter RSF.v1 List Spilter         =
=               [+] Python version-2                   =
=               [+] Automatically Find Domain File     =
=               [+] TG: @neel_info                     =
========================================================
""" + Style.RESET_ALL)

# Step 1: Automatically select largest .txt file
yList = find_largest_txt_file()
print(Fore.GREEN + "   Auto-selected list: {}".format(yList) + Style.RESET_ALL)

# Show Auto-selected Exploit (default)
auto_exploit = 'rsf.py'
print(Fore.GREEN + "   Auto-selected Exploit: {}".format(auto_exploit) + Style.RESET_ALL)

# Step 2: Ask how many CMDs to run (prompt exactly as you requested)
num_cmds_str = input_Fox(Fore.YELLOW + '   How many CMDs to run? --> : ' + Style.RESET_ALL)
try:
    num_cmds = int(num_cmds_str)
except:
    print(Fore.RED + "Invalid number for CMDs." + Style.RESET_ALL)
    sys.exit(1)

total_lines = count_lines(yList)
if num_cmds <= 0:
    print(Fore.RED + "Number of CMDs must be greater than 0." + Style.RESET_ALL)
    sys.exit(1)

maxi = total_lines // num_cmds
if total_lines % num_cmds != 0:
    maxi += 1  # Add 1 to make sure all lines are included

# === New behavior: start crack.py first (if present), then run rsf.py chunks ===
preferred_admin = 'crack.py'
if os.path.isfile(preferred_admin):
    # start crack.py in a new cmd window and keep the window open (/k)
    try:
        # Use python to run crack.py to avoid relying on .py file associations
        admin_cmd = 'python "{}"'.format(preferred_admin)
        os.system('start "Admin" cmd /k {}'.format(admin_cmd))
        print(Fore.GREEN + "   Started {} in a new cmd window.".format(preferred_admin) + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + "   Failed to start {}: {}".format(preferred_admin, e) + Style.RESET_ALL)
else:
    print(Fore.YELLOW + "   {} not found — skipping admin startup.".format(preferred_admin) + Style.RESET_ALL)

# No exploiter prompt — always use rsf.py after user inputs the number
# Run rsf.py via python command so it works regardless of .py associations
exp_cmd_template = 'python "{}" {{}}'.format(auto_exploit)  # will format with list filename

def run(yList, maxi, exp_template):
    # remove previous chunk files to avoid appending old content
    for f in os.listdir('.'):
        if f.startswith('list-') and f.endswith('.txt'):
            try:
                os.remove(f)
            except:
                pass

    with open(yList, 'r') as sites:
        number = 1
        counter = 1
        for site in sites:
            site = site.strip()
            if not site:
                continue
            if counter <= maxi:
                with open('list-{}.txt'.format(number), 'a') as f:
                    f.write(site + '\n')
                counter += 1
            else:
                # launch the exploit on the finished chunk in a new cmd window
                list_file = 'list-{}.txt'.format(number)
                cmd_to_run = exp_template.format(list_file)
                title = "Exploit-{}".format(number)
                os.system('start "{}" cmd /k {}'.format(title, cmd_to_run))
                number += 1
                with open('list-{}.txt'.format(number), 'a') as f:
                    f.write(site + '\n')
                counter = 2
        # Final chunk: run exploit on last chunk
        list_file = 'list-{}.txt'.format(number)
        cmd_to_run = exp_template.format(list_file)
        title = "Exploit-{}".format(number)
        os.system('start "{}" cmd /k {}'.format(title, cmd_to_run))

    print(Fore.GREEN + '\n   ./Done' + Style.RESET_ALL)

run(yList, maxi, exp_cmd_template)
