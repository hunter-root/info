@echo off
chcp 65001 >nul

:: Auto-request Administrator privileges for C:\ root write access
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: Keep working directory at script location
cd /d "%~dp0"

setlocal
title [ EXPLOIT WALLPAPER ENGINE // GREEN-RED TERMINAL ]
mode con: cols=95 lines=25
color 0A

:: ANSI Escape Codes (Green & Red Theme)
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do (
  set "ESC=%%b"
)
set "GREEN=%ESC%[92m"
set "DGREEN=%ESC%[32m"
set "RED=%ESC%[91m"
set "DRED=%ESC%[31m"
set "WHITE=%ESC%[97m"
set "GRAY=%ESC%[90m"
set "RESET=%ESC%[0m"

:: Paths (Change SRC if needed, e.g. %~dp0setting\exploit.jpg or %~dp0exploit.jpg)
set "SRC=%~dp0exploit.jpg"
if not exist "%SRC%" if exist "%~dp0setting\exploit.jpg" set "SRC=%~dp0setting\exploit.jpg"
set "DST=C:\exploit.jpg"

cls
echo %RED%  ╔════════════════════════════════════════════════════════════════════════════════════╗%RESET%
echo %GREEN%  ║                        %RED%[●]%GREEN% HUNTER PNG EXPLOIT DEPLOYMENT  %GREEN%                         ║ %RESET%
echo %RED%  ╚════════════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.
echo %RED%  ┌────────────────────────────────────────────────────────────────────────────────────┐%RESET%
echo %RED%  │ %GREEN%SOURCE PAYLOAD %RED%: %WHITE%%SRC%%RESET%           │
echo %RED%  │ %GREEN%TARGET DRIVE   %RED%: %WHITE%%DST%%RESET%                                                    │
echo %RED%  │ %GREEN%EXECUTION MODE %RED%: %GREEN%ELEVATED ADMIN // WIN32 API%RESET%                                       │
echo %RED%  └────────────────────────────────────────────────────────────────────────────────────┘%RESET%
echo.

:: Step 1: Verify source image
echo %GREEN%  [01/03] %DGREEN%Scanning source directory for image asset...%RESET%
if not exist "%SRC%" (
    echo.
    echo %RED%  ╔════════════════════════════════════════════════════════════════════════════════════╗%RESET%
    echo %RED%  ║  [!] ERROR: 'exploit.jpg' NOT FOUND!                                               ║%RESET%
    echo %RED%  ║  [i] Place 'exploit.jpg' beside this script or inside the 'setting' folder.        ║%RESET%
    echo %RED%  ╚════════════════════════════════════════════════════════════════════════════════════╝%RESET%
    echo.
    echo %GRAY%  Press any key to exit...%RESET%
    pause >nul
    exit /b 1
)
echo %GREEN%  [OK]    %WHITE%Asset located and verified.%RESET%

:: Step 2: Copy to C:\
echo %GREEN%  [02/03] %DGREEN%Transferring image to root drive C:\...%RESET%
copy /y "%SRC%" "%DST%" >nul
if errorlevel 1 (
    echo.
    echo %RED%  [!] ERROR: Write operation to C:\ failed! Check disk permissions.%RESET%
    echo.
    pause >nul
    exit /b 1
)
echo %GREEN%  [OK]    %WHITE%Deployed to %GREEN%%DST%%RESET%

:: Step 3: Apply as desktop wallpaper
echo %GREEN%  [03/03] %DGREEN%Injecting wallpaper into active desktop session...%RESET%
powershell -NoProfile -Command ^
  "$code = '[DllImport(\"user32.dll\", SetLastError = true)] public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);';" ^
  "$type = Add-Type -MemberDefinition $code -Name 'Wallpaper' -Namespace 'Win32' -PassThru;" ^
  "$type::SystemParametersInfo(20, 0, '%DST%', 3)" >nul

if errorlevel 1 (
    echo.
    echo %RED%  [!] ERROR: Failed to update desktop wallpaper via Win32 API!%RESET%
    echo.
    pause >nul
    exit /b 1
)
echo %GREEN%  [OK]    %WHITE%Desktop background synchronized.%RESET%

echo.
echo %RED%  ╔════════════════════════════════════════════════════════════════════════════════════╗%RESET%
echo %GREEN%  ║  [✓] MISSION COMPLETE %RED::  %WHITE%WALLPAPER ACTIVE FROM C:\exploit.jpg                  %GREEN%║%RESET%
echo %RED%  ╚════════════════════════════════════════════════════════════════════════════════════╝%RESET%
echo.
echo %GRAY%  Press any key to close terminal...%RESET%
pause >nul