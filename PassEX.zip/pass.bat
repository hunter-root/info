@echo off

REM Check if the script is running with administrative privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo This script must be run as Administrator. Please right-click and select "Run as administrator".
    pause
    exit /b
)

REM Change the password for the 'administrator' account
net user administrator sen@#271416

REM Check if the password was successfully changed
if %errorlevel% equ 0 (
    echo Password for 'Administrator' has been successfully changed.
) else (
    echo Failed to change the password for 'Administrator'. Please check if the username is correct or if password policies restrict this.
)

pause