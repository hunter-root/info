; EXE path Update This!
ExePath := "C:\Users\hunter\Desktop\CrakerV2.1\craker.exe"

; Windows Size
WinX := 100
WinY := 100
WinWidth := 1250
WinHeight := 650

; EXE Runing..
Run, %ExePath%, , , PID

; উইন্ডো fully ready হওয়া পর্যন্ত wait
WinWait, ahk_pid %PID%, , 10  ; 10 seconds timeout
if ErrorLevel
{
    MsgBox, উইন্ডো খোলা যায়নি বা 10 সেকেন্ডের মধ্যে handle পাওয়া যায়নি
    ExitApp
}

; উইন্ডো force move এবং resize
Loop 10
{
    WinMove, ahk_pid %PID%, , WinX, WinY, WinWidth, WinHeight
    Sleep, 100
}